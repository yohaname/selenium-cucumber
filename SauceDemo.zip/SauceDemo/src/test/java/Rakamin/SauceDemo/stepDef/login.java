package Rakamin.SauceDemo.stepDef;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

import java.util.concurrent.TimeUnit;

public class login {

    WebDriver driver;

    String link = "https://www.saucedemo.com/";

    @Given("Buka SauceDemo")
    public void Buka_SauceDemo() {
        System.setProperty("webdriver.gecko.driver","C:\\Users\\Yohana\\IdeaProjects\\SauceDemo\\geckodriver.exe");
        WebDriverManager.firefoxdriver().setup();
        FirefoxOptions opt = new FirefoxOptions();
        opt.setHeadless(false);

        driver= new FirefoxDriver(opt);
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        driver.get(link);
    }

    @Then("Isi Username valid")
    public void Isi_Username_valid() {
        driver.findElement(By.id("user-name")).sendKeys("standard_user");
    }

    @And("Isi Password valid")
    public void Isi_Password_valid() {
        driver.findElement(By.id("password")).sendKeys("secret_sauce");
    }

    @Then("Klik Login")
    public void Klik_Login() {
        driver.findElement(By.id("login-button")).click();
    }



}
