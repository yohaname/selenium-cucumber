package SauceDemo.stepDef;

public class login_gagal {
}
