package SauceDemo.stepDef;

public class cart {
}
